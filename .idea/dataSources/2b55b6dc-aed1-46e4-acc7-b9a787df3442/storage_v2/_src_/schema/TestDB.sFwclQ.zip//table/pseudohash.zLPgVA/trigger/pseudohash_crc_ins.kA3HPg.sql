create definer = root@`%` trigger pseudohash_crc_ins
  before INSERT
  on pseudohash
  for each row
BEGIN SET
NEW.url_crc=crc32(New.url);
END;

